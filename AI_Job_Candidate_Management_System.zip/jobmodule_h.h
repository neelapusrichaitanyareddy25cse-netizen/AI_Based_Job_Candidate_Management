#ifndef JOB_CATALOG_H
#define JOB_CATALOG_H

#define JOB_NAME_SIZE 80
#define JOB_SKILLS_SIZE 200

typedef struct JobEntry {
    int jobId;
    char jobTitle[JOB_NAME_SIZE];
    char skillCriteria[JOB_SKILLS_SIZE];
    float experienceRequired;
    struct JobEntry *nextEntry;
} JobEntry;

extern JobEntry *firstJob;

void addJob(void);
void listAvailableJobs(void);
JobEntry *searchJob(int jobId);
void clearJobRecords(void);

#endif