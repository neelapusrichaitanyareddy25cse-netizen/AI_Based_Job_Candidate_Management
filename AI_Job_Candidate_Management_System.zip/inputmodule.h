#ifndef INPUT_MODULE_H
#define INPUT_MODULE_H

int readInt(const char *prompt);
float readFloat(const char *prompt);
void readLine(const char *prompt, char *buffer, int capacity);

#endif
