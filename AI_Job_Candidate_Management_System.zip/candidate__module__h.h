#ifndef CANDIDATE_REGISTRY_H
#define CANDIDATE_REGISTRY_H

#include <stddef.h>

enum {
    CANDIDATE_NAME_CAP = 60,
    CANDIDATE_EDUCATION_CAP = 100,
    CANDIDATE_SKILLS_CAP = 200
};

typedef struct Candidate Candidate;

struct Candidate {
    unsigned int id;
    char name[CANDIDATE_NAME_CAP];
    char education[CANDIDATE_EDUCATION_CAP];
    char skills[CANDIDATE_SKILLS_CAP];
    float experience;
    Candidate *next;
};

/* Operations supported by the candidate registry */
void registerCandidate(void);
void displayCandidates(void);
const Candidate *lookupCandidate(unsigned int id);
void clearCandidateRegistry(void);

#endif